
package javaapplication6;

public class JavaApplication6 {

  
    public static void main(String[] args) {
          Oda oda = new Oda("Misafir Odası", 30);

        Koltuk koltuk1 = new Koltuk(new Konum(20, 50), "Mavi", 1);
        Koltuk koltuk2 = new Koltuk(new Konum(300, 100), "Gri", 3);
        Masa masa = new Masa(new Konum(100, 200), "Kahve", 4, 2);

        oda.mobilyaEkle(koltuk1);
        oda.mobilyaEkle(koltuk2);
        oda.mobilyaEkle(masa);

        oda.listele();
        oda.tümünüGöster();
    

    }
    
}
